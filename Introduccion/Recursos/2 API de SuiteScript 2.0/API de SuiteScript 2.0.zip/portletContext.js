/**
 * SuiteScript module
 *
 * @module N/portletContext
 * @NApiVersion 2.x
 *
 */
define([], function(){        
    /**
     * @namespace portletContext
     */    
    var portletContext = {};    
        
    N.portletContext = portletContext;
    
    /**
     * @exports N/portletContext
     */
    return portletContext;
});