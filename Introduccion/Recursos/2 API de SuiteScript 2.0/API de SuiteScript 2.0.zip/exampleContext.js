/**
 * SuiteScript module - defines the good example and bad example objects
 *
 * @module N/exampleContext
 * @NApiVersion 2.x
 *
 */
define([], function(){        
    /**
     * @namespace exampleContext
     */    
    var exampleContext = {};    
        
    N.exampleContext = exampleContext;
    
    /**
     * @exports N/exampleContext
     */
    return exampleContext;
});