/**
 * SuiteScript UI Module (Client Side)
 *
 * @module N/ui
 * @suiteScriptVersion 2.x
 *
 */
define([], function(){        
    /**
     * @namespace ui
     */    
    var ui = {};    
        
    N.ui = ui;
    
    /**
     * @exports N/ui
     */
    return ui;
});