/**
 * SuiteScript Form Record Bootstrap Module
 *
 * @module N/currentRecordBootstrap
 * @suiteScriptVersion 2.x
 *
 */
define([], function(){        
    /**
     * @namespace currentRecordBootstrap
     */    
    var currentRecordBootstrap = {};    
        
    N.currentRecordBootstrap = currentRecordBootstrap;
    
    /**
     * @exports N/currentRecordBootstrap
     */
    return currentRecordBootstrap;
});