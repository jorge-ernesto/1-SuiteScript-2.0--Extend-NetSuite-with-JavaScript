/**
 * @module N/erp/item/catchWeight
 * @NApiVersion 2.x
 *
 */
define([], function(){        
    /**
     * @namespace catchWeight
     */    
    var catchWeight = {};    
        
    var erp = {};
N.erp = erp;
    var item = {};
erp.item = item;
    item.catchWeight = catchWeight;
    
    /**
     * @exports N/erp/item/catchWeight
     */
    return catchWeight;
});