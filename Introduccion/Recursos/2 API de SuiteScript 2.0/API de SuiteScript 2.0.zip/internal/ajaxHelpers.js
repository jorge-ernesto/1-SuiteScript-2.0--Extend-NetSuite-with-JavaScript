/**
 * SuiteScript module
 *
 * @private
 * @module N/internal/ajaxHelpers
 * @NApiVersion 2.x
 */
define([], function(){        
    /**
     * @namespace ajaxHelpers
     */    
    var ajaxHelpers = {};    
        
    var internal = {};
N.internal = internal;
    internal.ajaxHelpers = ajaxHelpers;
    
    /**
     * @exports N/internal/ajaxHelpers
     */
    return ajaxHelpers;
});