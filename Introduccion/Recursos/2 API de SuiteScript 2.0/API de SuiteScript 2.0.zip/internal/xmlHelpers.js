/**
 * SuiteScript module
 *
 * @private
 * @module N/internal/xmlHelpers
 * @NApiVersion 2.x
 */
define([], function(){        
    /**
     * @namespace xmlHelpers
     */    
    var xmlHelpers = {};    
        
    var internal = {};
N.internal = internal;
    internal.xmlHelpers = xmlHelpers;
    
    /**
     * @exports N/internal/xmlHelpers
     */
    return xmlHelpers;
});